#!/bin/bash

if [ -e dsl.img ] ;  then
  # Later boots, once installed on the hard drive.
  #qemu-system-i386 -hda dsl.img
  kvm -hda dsl.img
else
  # First boot, we must first create a disk
  echo Creating Damn-Small-Linux hard disk...
  qemu-img create -f raw dsl.img 128M
  # Now let's boot DSL as a livecd,
  # notice the boot order, cdrom first.
  # qemu-system-i386 -cdrom dsl-4.4.10.iso -hda dsl.img -boot order=dc
  echo Boot Damn-Small-Linux as a livecd...
  kvm -cdrom dsl-4.4.10.iso -hda dsl.img -boot order=dc
fi



